// lib/providers/shopping_list_peek_provider.dart
//
// Tracks whether the user has ever completed a full swipe-to-delete on the
// shopping list. While that's false, the first item in the list plays a
// short "peek" animation every time the screen opens, hinting that swiping
// is possible. Once they swipe for real, this flips to true forever.
//
// Requires the `shared_preferences` package — add it to pubspec.yaml if
// it isn't already a dependency.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _hasSwipedKey = 'shopping_list_has_swiped_to_delete';

/// Resolves to `true` once the user has completed at least one real
/// swipe-to-delete, `false` if they never have.
///
/// autoDispose so it re-reads from SharedPreferences fresh every time the
/// shopping list screen is opened, satisfying "must repeat every time the
/// screen is opened until the user's first successful swipe".
final shoppingListHasSwipedProvider =
    FutureProvider.autoDispose<bool>((ref) async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool(_hasSwipedKey) ?? false;
});

/// Call this exactly once, from Dismissible.onDismissed, the first time a
/// real swipe-to-delete completes.
Future<void> markShoppingListHasSwiped(WidgetRef ref) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_hasSwipedKey, true);
  // So a later open of this screen re-reads the now-true value instead of
  // a stale cached one.
  ref.invalidate(shoppingListHasSwipedProvider);
}
