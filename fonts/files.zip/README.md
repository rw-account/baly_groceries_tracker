# Shopping List: Multi-Select + Swipe Peek Hint

## Files

**New:**
- `lib/providers/shopping_list_selection_provider.dart` — selection-mode state (Feature 1)
- `lib/providers/shopping_list_peek_provider.dart` — SharedPreferences-backed "has swiped" flag (Feature 2)
- `lib/core/widgets/shopping_item_card.dart` — reconstructed (see below)

**Updated (drop-in replacements):**
- `lib/screens/shopping_list/shopping_list_screen.dart`
- `lib/screens/shopping_list/widgets/shopping_list_view.dart`

**Untouched:**
- `shopping_list_empty_state.dart`, `shopping_list_total_bar.dart`, `widgets.dart`, the `ShoppingItem` model, `shoppingListProvider` — none of these needed to change.

## One dependency to add

```yaml
dependencies:
  shared_preferences: ^2.x
```

## The one thing you should double check: `shopping_item_card.dart`

This file wasn't in your upload — only its call site (`ShoppingItemCard(item: item, onDelete: onDelete)`) was visible. I rebuilt it to match your app's style, but I had to guess at two things that directly affect "don't break the existing Dismissible":

1. **Swipe direction.** Set to `DismissDirection.startToEnd` so the real swipe matches the "slide right" peek hint you specified. If your actual card swipes the other way, flip it to `endToStart` (and mirror the background's `Alignment.centerLeft` → `centerRight`).
2. **"Checkbox on the left."** Implemented as the *leading* edge (right side, since the app is RTL). If you meant literally, physically left regardless of text direction, swap `EdgeInsetsDirectional` for plain `EdgeInsets` in `_buildCardContent`.

If your real card differs more substantially (a leading image, an existing `onTap` that opens an edit screen, different fields), send it over — the selection/peek code is isolated into clearly marked blocks so it's a quick graft rather than a rewrite.

## How it works

**Selection mode** — `shoppingListSelectionProvider` holds `isSelectionMode` + `selectedIds`, kept fully separate from your data provider and model. `ShoppingItemCard` watches it directly:
- Long-press → `startSelection(id)` → enters selection mode, selects that item, background/border change, checkbox fades in.
- Tap while in selection mode → `toggle(id)`.
- While in selection mode, the `Dismissible` is swapped out for a plain `GestureDetector` — so there's no chance of a stray swipe firing mid-selection, and the real swipe-to-delete is completely unaffected outside selection mode.
- Cancel button, the AppBar's back arrow, and the system back button (via `PopScope`) all call `.exit()`.
- Delete button confirms via dialog, loops `deleteShoppingItem()` per selected id (no bulk-delete method existed on your provider to call directly), then shows the same undo Snackbar+countdown pattern your single-delete flow already uses — I extracted that into one shared `_showUndoSnackBar()` helper so both paths look and behave identically.

**Peek hint** — `shoppingListHasSwipedProvider` (a `FutureProvider`) reads a bool from `SharedPreferences` fresh every time the screen mounts. `ShoppingListView` passes `showPeekHint: index == 0 && !hasSwiped` to just the first card. That card runs a `TweenSequence`-free `AnimationController` (slide out 300ms → hold 400ms → slide back 300ms) that translates the row 12% of the screen width to the right and reveals a manually-drawn red delete background behind it — real `Dismissible` backgrounds only render during an actual drag, so the hint fakes the same visual with a `Stack` + `Transform.translate`. The real swipe still works normally underneath; the hint is purely a translated overlay that ignores pointer events while it plays. The moment the user completes one real swipe, `markShoppingListHasSwiped()` writes `true` to prefs and the hint never appears again.
