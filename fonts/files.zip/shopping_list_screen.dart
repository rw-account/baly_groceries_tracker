// lib/screens/shopping_list/shopping_list_screen.dart

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';

import '../../../models/shopping_item_model.dart';
import '../../../providers/shopping_list_provider.dart';
import '../../../providers/shopping_list_selection_provider.dart';
import '../../../router/route_paths.dart';
import 'widgets/widgets.dart';

class ShoppingListScreen extends ConsumerStatefulWidget {
  const ShoppingListScreen({super.key});

  @override
  ConsumerState<ShoppingListScreen> createState() => _ShoppingListScreenState();
}

class _ShoppingListScreenState extends ConsumerState<ShoppingListScreen> {

  // 🔴 Local timer for the undo SnackBar (single delete AND bulk delete
  // now share this — see _showUndoSnackBar).
  // ⏱️ Used to auto-hide the SnackBar after the undo window expires.
  Timer? snackBarTimer;

  @override
  void dispose() {
    snackBarTimer?.cancel();
    super.dispose();
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
          ),
          backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
        )
      );
  }

  @override
  Widget build(BuildContext context) {
    final shoppingAsync = ref.watch(shoppingListProvider);
    final selection = ref.watch(shoppingListSelectionProvider);

    final showFab = !selection.isSelectionMode &&
        shoppingAsync.maybeWhen(
          data: (items) => items.isNotEmpty,
          orElse: () => false,
        );

    return PopScope(
      // Feature 1, requirement 4: system back button clears selection and
      // exits selection mode instead of leaving the screen.
      canPop: !selection.isSelectionMode,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) {
          ref.read(shoppingListSelectionProvider.notifier).exit();
        }
      },
      child: Scaffold(
        appBar: selection.isSelectionMode
            ? _buildSelectionAppBar(context, selection)
            : _buildDefaultAppBar(context),
        body: shoppingAsync.when(
          data: (items) {
            if (items.isEmpty) {
              return ShoppingListEmptyState(
                onAddPressed: () => context.push(RoutePaths.addShoppingItemFull),
              );
            }
            return ShoppingListView(
              items: items,
              onDelete: _deleteShoppingItem,
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stack) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'حدث خطأ: $error',
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          ),
        ),
        floatingActionButton: showFab
            ? Padding(
                padding: const EdgeInsets.only(bottom: 70, left: 3),
                child: FloatingActionButton(
                  onPressed: () => context.push(RoutePaths.addShoppingItemFull),
                  child: const Icon(Icons.add),
                ),
              )
            : null,
      ),
    );
  }

  // ─── AppBars ───────────────────────────────────────────────────────

  AppBar _buildDefaultAppBar(BuildContext context) {
    return AppBar(
      title: const Text('قائمة الشراء'),
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 1,
      actions: [
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          position: PopupMenuPosition.under,
          onSelected: (value) {
            switch (value) {
              case 'delete_all':
                _confirmDeleteAll();
                break;
              case 'share_list':
                _shareList();
                break;
            }
          },
          itemBuilder: (context) => [
             PopupMenuItem(
              value: 'delete_all',
              child: Row(
                children: [
                  Icon(Icons.delete_outline, size: 20, color: Theme.of(context).colorScheme.error),
                  const SizedBox(width: 8),
                  const Text('حذف كل العناصر'),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'share_list',
              child: Row(
                children: [
                  Icon(Icons.share_outlined, size: 20, color: Theme.of(context).colorScheme.primary),
                  SizedBox(width: 8),
                  Text('مشاركة القائمة'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // Feature 1, requirement 1 & 3: selection-mode AppBar with count,
  // delete, and cancel.
  AppBar _buildSelectionAppBar(
    BuildContext context,
    ShoppingListSelectionState selection,
  ) {
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.close),
        tooltip: 'إلغاء',
        onPressed: () => ref.read(shoppingListSelectionProvider.notifier).exit(),
      ),
      title: Text('${selection.count} محدد'),
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 1,
      actions: [
        IconButton(
          icon: const Icon(Icons.delete_outline),
          tooltip: 'حذف',
          onPressed: selection.count == 0
              ? null
              : () => _confirmBulkDelete(selection.selectedIds),
        ),
      ],
    );
  }

  // ─── حذف عنصر واحد (swipe-to-delete / single delete) ───────────────
  Future<void> _deleteShoppingItem(ShoppingItem item) async {
    final id = item.id;
    if (id == null) return;

    try {
      await ref.read(shoppingListProvider.notifier).deleteShoppingItem(id);
    } catch (e) {
      _showSnackBar('تعذر حذف "${item.title}"');
      return;
    }

    if (!mounted) return;

    _showUndoSnackBar(
      message: 'تم حذف "${item.title}"',
      onUndo: () => _restoreShoppingItem(item),
    );
  }

  Future<void> _restoreShoppingItem(ShoppingItem item) async {
    await ref.read(shoppingListProvider.notifier).addShoppingItem(
          title: item.title,
          inventoryItemId: item.inventoryItemId,
          price: item.price,
          isChecked: item.isChecked,
          createdAt: item.createdAt,
        );
  }

  // ─── حذف جماعي (multi-select bulk delete) ───────────────────────────
  //
  // Feature 1, requirement 3. Loops deleteShoppingItem() per selected id
  // rather than assuming shoppingListProvider has a bulk-delete method,
  // since that file wasn't available to confirm. If your notifier does
  // have (or you add) a batch delete API, swap the loop below for a
  // single call — it'll be faster for large selections.
  Future<void> _confirmBulkDelete(Set<Object> ids) async {
    if (ids.isEmpty) return;
    final count = ids.length;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العناصر المحددة'),
        content: Text('هل تريد حذف $count عناصر؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
              foregroundColor: Theme.of(ctx).colorScheme.onError,
            ),
            child: const Text('حذف'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final currentItems = ref.read(shoppingListProvider).value ?? [];
    final itemsToDelete =
        currentItems.where((it) => it.id != null && ids.contains(it.id)).toList();

    final restored = <ShoppingItem>[];
    var failures = 0;
    for (final item in itemsToDelete) {
      try {
        await ref.read(shoppingListProvider.notifier).deleteShoppingItem(item.id!);
        restored.add(item);
      } catch (_) {
        failures++;
      }
    }

    ref.read(shoppingListSelectionProvider.notifier).exit();
    if (!mounted) return;

    if (restored.isEmpty) {
      _showSnackBar('تعذر حذف العناصر المحددة');
      return;
    }

    final message = failures == 0
        ? 'تم حذف ${restored.length} عناصر'
        : 'تم حذف ${restored.length} عناصر، تعذر حذف $failures';

    _showUndoSnackBar(
      message: message,
      onUndo: () async {
        for (final item in restored) {
          await _restoreShoppingItem(item);
        }
      },
    );
  }

  // ─── SnackBar مع تراجع وعدّاد تنازلي (shared by single + bulk delete) ──
  //
  // NOTE: This non-standard approach was adopted after trying the usual
  // ways of showing a SnackBar with an "Undo" action. The issue was that
  // the SnackBar would remain visible and would not dismiss automatically
  // after the user tapped "Undo".
  //
  // This solution uses a Timer to take full control over dismissing the
  // SnackBar manually after 5 seconds, regardless of widget rebuilds.
  // A visible countdown was also added to improve the user experience by
  // showing how much time remains to undo the action.
  void _showUndoSnackBar({
    required String message,
    required Future<void> Function() onUndo,
  }) {
    if (!mounted) return;

    const int durationSeconds = 5;
    final scaffoldMessenger = ScaffoldMessenger.of(context);
    final theme = Theme.of(context);

    // Immediately cancel any previous timer so an old timer doesn't "wake
    // up" later and incorrectly dismiss the new SnackBar.
    snackBarTimer?.cancel();
    scaffoldMessenger.hideCurrentSnackBar();

    scaffoldMessenger.showSnackBar(
      SnackBar(
        duration: const Duration(seconds: durationSeconds),
        content: Row(
          children: [
            Expanded(
              child: Text(message, style: TextStyle(color: theme.colorScheme.onSurface)),
            ),
            // Circular and numeric countdown timer.
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: durationSeconds.toDouble(), end: 0.0),
              duration: const Duration(seconds: durationSeconds),
              builder: (context, value, child) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${value.ceil()}',
                      style: TextStyle(
                        color: theme.colorScheme.onSurface,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(
                        value: value / durationSeconds,
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.onSurface),
                      ),
                    ),
                  ],
                );
              },
            ),
            const SizedBox(width: 8),
          ],
        ),
        backgroundColor: theme.colorScheme.surfaceContainerHighest,
        action: SnackBarAction(
          label: 'تراجع',
          textColor: theme.colorScheme.onSurface,
          onPressed: () {
            snackBarTimer?.cancel(); // ❌ Cancel the sleep timer, user tapped Undo.
            onUndo();
          },
        ),
      ),
    );

    // ⏳ Sleep function (5-second timer).
    snackBarTimer = Timer(const Duration(seconds: durationSeconds), () {
      if (mounted) {
        scaffoldMessenger.hideCurrentSnackBar(); // 👈 Called immediately after the timer expires.
      }
    });
  }

  // ─── حذف الكل ──────────────────────────────────────────────────────
  Future<void> _confirmDeleteAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف جميع العناصر'),
        content: const Text('هل أنت متأكد من حذف كل عناصر قائمة الشراء؟ لا يمكن التراجع.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
              foregroundColor: Theme.of(ctx).colorScheme.onError,
            ),
            child: const Text('حذف الكل'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      await ref.read(shoppingListProvider.notifier).clearAll();
      _showSnackBar('تم حذف جميع عناصر قائمة الشراء');
    } catch (_) {
      _showSnackBar('تعذر حذف جميع عناصر قائمة الشراء');
    }
  }

  // ─── مشاركة القائمة ──────────────────────────────────────────────
  Future<void> _shareList() async {
    final items = ref.read(shoppingListProvider).value ?? [];
    if (items.isEmpty) {
      _showSnackBar('القائمة فارغة');
      return;
    }

    // القيم الافتراضية (كل شيء محدد)
    bool includePrice = true;
    bool includeChecked = true;

    // إظهار نافذة خيارات المشاركة
    // بارامتر barrierDismissible: true (افتراضي) يسمح بالإغلاق عند الضغط خارج النافذة
    final result = await showDialog<List<bool>>(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('خيارات المشاركة'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CheckboxListTile(
                    title: const Text('تضمين السعر'),
                    value: includePrice,
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() => includePrice = val);
                      }
                    },
                    contentPadding: EdgeInsets.zero,
                  ),
                  CheckboxListTile(
                    title: const Text('تضمين حالة الشراء'),
                    value: includeChecked,
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() => includeChecked = val);
                      }
                    },
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              actions: [
                TextButton(
                  // إرجاع null عند الإلغاء
                  onPressed: () => Navigator.pop(ctx, null),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  // إرجاع القيم المحددة عند الموافقة
                  onPressed: () => Navigator.pop(ctx, [includePrice, includeChecked]),
                  child: const Text('مشاركة'),
                ),
              ],
            );
          },
        );
      },
    );

    // إذا أغلق المستخدم النافذة (بالضغط خارجها أو زر الإلغاء)، لا تفعل شيئاً
    if (result == null) return;

    final shouldIncludePrice = result[0];
    final shouldIncludeChecked = result[1];

    final buffer = StringBuffer();
    buffer.writeln('🛒 قائمة الشراء:');

    for (final item in items) {
      //TODO: ملاحظه مهمه لا تحذفها: عند تحويل لغة التطبيق الى الانجليزي يجب انك تغير اتجاه ايموجي اليد وتجيب ايموجي يشير للجهه الاخرى
      String line = '• ${item.title}';

      if (shouldIncludePrice && item.price != null) {
        line += ' 👈 (السعر: ${item.price})';
      }

      if (shouldIncludeChecked && item.isChecked) {
        line += ' [مكتمل ✓]';
      }

      buffer.writeln(line);
    }

    // مشاركة النص المجمّع
    SharePlus.instance.share(
      ShareParams(text: buffer.toString()),
    );
  }
}
