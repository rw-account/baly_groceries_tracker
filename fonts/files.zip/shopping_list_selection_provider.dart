// lib/providers/shopping_list_selection_provider.dart
//
// Selection-mode state for the shopping list, kept completely separate
// from `shoppingListProvider` and the `ShoppingItem` model. That
// separation is what lets multi-select live alongside the existing
// Dismissible / swipe-to-delete without touching either.
//
// `id` is typed as Object rather than int/String because the model file
// wasn't available to confirm ShoppingItem.id's real type — Object works
// for either and set membership (`==`) behaves correctly for both.

import 'package:flutter_riverpod/flutter_riverpod.dart';

@immutable
class ShoppingListSelectionState {
  const ShoppingListSelectionState({
    this.isSelectionMode = false,
    this.selectedIds = const <Object>{},
  });

  final bool isSelectionMode;
  final Set<Object> selectedIds;

  int get count => selectedIds.length;

  bool isSelected(Object id) => selectedIds.contains(id);

  ShoppingListSelectionState copyWith({
    bool? isSelectionMode,
    Set<Object>? selectedIds,
  }) {
    return ShoppingListSelectionState(
      isSelectionMode: isSelectionMode ?? this.isSelectionMode,
      selectedIds: selectedIds ?? this.selectedIds,
    );
  }
}

class ShoppingListSelectionNotifier
    extends StateNotifier<ShoppingListSelectionState> {
  ShoppingListSelectionNotifier() : super(const ShoppingListSelectionState());

  /// Long-press on an item: enters selection mode with that item selected.
  void startSelection(Object id) {
    state = ShoppingListSelectionState(
      isSelectionMode: true,
      selectedIds: {id},
    );
  }

  /// Tap on an item while already in selection mode: toggles it.
  ///
  /// Auto-exits selection mode once the last item is deselected — a common
  /// UX default. Delete the `isSelectionMode: next.isNotEmpty` line below
  /// if you'd rather selection mode stay open (with 0 selected) until the
  /// user explicitly hits Cancel.
  void toggle(Object id) {
    if (!state.isSelectionMode) return;
    final next = Set<Object>.from(state.selectedIds);
    if (!next.remove(id)) {
      next.add(id);
    }
    state = state.copyWith(
      selectedIds: next,
      isSelectionMode: next.isNotEmpty,
    );
  }

  /// Cancel button or system back button.
  void exit() {
    state = const ShoppingListSelectionState();
  }
}

final shoppingListSelectionProvider = StateNotifierProvider.autoDispose<
    ShoppingListSelectionNotifier, ShoppingListSelectionState>(
  (ref) => ShoppingListSelectionNotifier(),
);
