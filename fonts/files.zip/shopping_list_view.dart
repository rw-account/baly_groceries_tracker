// lib/screens/shopping_list/widgets/shopping_list_view.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../models/shopping_item_model.dart';
import '../../../core/widgets/shopping_item_card.dart';
import '../../../providers/shopping_list_peek_provider.dart';
import 'shopping_list_total_bar.dart';

/// Renders the list of shopping items plus the running total bar.
/// Used for the "data" case of [shoppingListProvider] once the list
/// is known to be non-empty.
///
/// Changed from StatelessWidget -> ConsumerWidget to read the "has the
/// user ever swiped" flag, which decides whether item 0 plays the peek
/// hint (Feature 2). Everything else is unchanged from the original.
class ShoppingListView extends ConsumerWidget {
  const ShoppingListView({
    super.key,
    required this.items,
    required this.onDelete,
  });

  final List<ShoppingItem> items;
  final ValueChanged<ShoppingItem> onDelete;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final total = items.fold<double>(
      0,
      (sum, item) => sum + (item.price ?? 0),
    );

    // Default to "true" (no hint) while the SharedPreferences read is still
    // in flight, so a returning user never sees a false flash of the peek
    // animation. Tradeoff: on a genuinely first-ever cold start, if that
    // read hasn't resolved by the first frame, that single peek could be
    // skipped — a non-issue if you already warm up SharedPreferences in
    // main() before this screen builds.
    final hasSwiped = ref.watch(shoppingListHasSwipedProvider).maybeWhen(
          data: (value) => value,
          orElse: () => true,
        );

    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 80),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ShoppingItemCard(
                  item: item,
                  onDelete: onDelete,
                  showPeekHint: index == 0 && !hasSwiped,
                ),
              );
            },
          ),
        ),
        ShoppingListTotalBar(total: total),
      ],
    );
  }
}
