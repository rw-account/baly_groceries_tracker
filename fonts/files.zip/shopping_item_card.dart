// lib/core/widgets/shopping_item_card.dart
//
// ⚠️ ASSUMPTION FLAG ⚠️
// This file was NOT part of what you uploaded — only its usage
// (`ShoppingItemCard(item: item, onDelete: onDelete)`) was visible from
// shopping_list_view.dart. Everything below is a reconstruction built to
// match the visual language of your other widgets (Material 3 tokens,
// Arabic RTL, same colorScheme usage as shopping_list_total_bar.dart /
// shopping_list_empty_state.dart).
//
// If your real card looks/behaves differently (different fields shown, a
// leading image, an existing onTap that opens an edit screen, a different
// swipe direction/background, etc.), send it over and I'll graft these two
// features onto the real thing instead — the selection- and peek-specific
// code is isolated below so it's easy to lift out.
//
// Two things I had to guess and want to call out explicitly:
//   1. Swipe direction — set to DismissDirection.startToEnd (drag toward
//      the right) so the real gesture matches the "slide right" peek hint
//      you specified. Flip to endToStart if your actual delete swipe goes
//      the other way.
//   2. "Checkbox on the left" — implemented as the *leading* edge via
//      EdgeInsetsDirectional, which is the right side in this RTL app.
//      If you meant literally, physically left regardless of text
//      direction, swap EdgeInsetsDirectional for a fixed EdgeInsets below.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/shopping_item_model.dart';
import '../../providers/shopping_list_selection_provider.dart';
import '../../providers/shopping_list_peek_provider.dart';

class ShoppingItemCard extends ConsumerStatefulWidget {
  const ShoppingItemCard({
    super.key,
    required this.item,
    required this.onDelete,
    this.showPeekHint = false,
  });

  final ShoppingItem item;
  final ValueChanged<ShoppingItem> onDelete;

  /// Plays the one-off "peek" swipe hint shortly after this card mounts.
  /// Should only ever be true for the first item in the list, and only
  /// while the user hasn't completed a real swipe-to-delete before.
  final bool showPeekHint;

  @override
  ConsumerState<ShoppingItemCard> createState() => _ShoppingItemCardState();
}

class _ShoppingItemCardState extends ConsumerState<ShoppingItemCard>
    with SingleTickerProviderStateMixin {
  // ── Feature 2: peek hint tuning ──────────────────────────────────────
  static const _peekFraction = 0.12; // 12% of the row width
  static const _peekSlideDuration = Duration(milliseconds: 300);
  static const _peekHoldDuration = Duration(milliseconds: 400); // per spec

  late final AnimationController _peekController;
  late final Animation<double> _peekAnimation;
  bool _isPeekPlaying = false;

  @override
  void initState() {
    super.initState();

    _peekController =
        AnimationController(vsync: this, duration: _peekSlideDuration);
    _peekAnimation =
        CurvedAnimation(parent: _peekController, curve: Curves.easeOut);

    if (widget.showPeekHint) {
      // Wait for the first real frame so the row has a measurable width.
      WidgetsBinding.instance.addPostFrameCallback((_) => _playPeek());
    }
  }

  Future<void> _playPeek() async {
    if (!mounted) return;
    setState(() => _isPeekPlaying = true);
    await _peekController.forward();
    if (!mounted) return;
    await Future.delayed(_peekHoldDuration);
    if (!mounted) return;
    await _peekController.reverse();
    if (!mounted) return;
    setState(() => _isPeekPlaying = false);
  }

  @override
  void dispose() {
    _peekController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final item = widget.item;
    final id = item.id;

    // ── Feature 1: selection mode ────────────────────────────────────
    final selection = ref.watch(shoppingListSelectionProvider);
    final isSelectionMode = selection.isSelectionMode;
    final isSelected = id != null && selection.isSelected(id);

    final card = _buildCardContent(theme, isSelectionMode, isSelected);

    if (isSelectionMode) {
      // Swipe is intentionally disabled in selection mode — tap toggles
      // instead. This is what keeps this feature from ever fighting with
      // the Dismissible below.
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: id == null
            ? null
            : () => ref.read(shoppingListSelectionProvider.notifier).toggle(id),
        child: card,
      );
    }

    // ── Normal mode: your existing swipe-to-delete, untouched in spirit ──
    final dismissible = Dismissible(
      key: ValueKey('shopping_item_${id ?? item.hashCode}'),
      direction: DismissDirection.startToEnd, // see assumption note above
      background: _buildDeleteBackground(theme),
      onDismissed: (_) {
        markShoppingListHasSwiped(ref); // first-ever swipe -> stop hinting
        widget.onDelete(item);
      },
      child: GestureDetector(
        onLongPress: id == null
            ? null
            : () => ref
                .read(shoppingListSelectionProvider.notifier)
                .startSelection(id),
        // TODO: if your real card has an existing onTap (e.g. opening an
        // edit screen), wire it in here — it only needs to be active when
        // NOT in selection mode, which this branch already guarantees.
        child: card,
      ),
    );

    if (!widget.showPeekHint) return dismissible;

    // ── Peek overlay: only ever attached to the first item ──────────────
    return AnimatedBuilder(
      animation: _peekAnimation,
      builder: (context, child) {
        final dx = MediaQuery.of(context).size.width *
            _peekFraction *
            _peekAnimation.value;
        return Stack(
          children: [
            if (_peekAnimation.value > 0)
              Positioned.fill(child: _buildDeleteBackground(theme)),
            Transform.translate(
              offset: Offset(dx, 0),
              child: IgnorePointer(ignoring: _isPeekPlaying, child: child),
            ),
          ],
        );
      },
      child: dismissible,
    );
  }

  Widget _buildDeleteBackground(ThemeData theme) {
    return Container(
      alignment: Alignment.centerLeft, // side revealed by the rightward slide
      padding: const EdgeInsets.only(left: 20),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: theme.colorScheme.error,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(Icons.delete_outline, color: theme.colorScheme.onError),
    );
  }

  Widget _buildCardContent(
    ThemeData theme,
    bool isSelectionMode,
    bool isSelected,
  ) {
    final item = widget.item;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      decoration: BoxDecoration(
        color: isSelected
            ? theme.colorScheme.primaryContainer.withValues(alpha: 0.55)
            : theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? theme.colorScheme.primary
              : theme.colorScheme.outlineVariant,
          width: isSelected ? 1.5 : 1,
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 150),
            child: isSelectionMode
                ? Padding(
                    key: const ValueKey('checkbox'),
                    padding: const EdgeInsetsDirectional.only(end: 10),
                    child: Checkbox(
                      value: isSelected,
                      shape: const CircleBorder(),
                      onChanged: item.id == null
                          ? null
                          : (_) => ref
                              .read(shoppingListSelectionProvider.notifier)
                              .toggle(item.id!),
                    ),
                  )
                : const SizedBox(key: ValueKey('no_checkbox'), width: 0),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    decoration:
                        item.isChecked ? TextDecoration.lineThrough : null,
                    color: item.isChecked
                        ? theme.colorScheme.onSurfaceVariant
                        : theme.colorScheme.onSurface,
                  ),
                ),
                if (item.price != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    item.price!.toStringAsFixed(2),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
